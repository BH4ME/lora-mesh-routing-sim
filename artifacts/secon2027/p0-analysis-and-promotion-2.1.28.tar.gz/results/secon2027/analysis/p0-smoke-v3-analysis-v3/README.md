# P0 smoke analysis validation only — v3

This is the current verification of the final analyzer against all 21 immutable `p0-smoke-v3` runs. It supersedes v2 as source-provenance verification. All smoke CSV files are byte-identical to v2, and this smoke workload has no load curve. Earlier analyses and raw evidence remain unchanged.

A4 is fixed: load lines require identical actual per-seed resolved protocol parameters as well as the same non-load configuration. Equivalent explicit/omitted defaults match by their resolved values. Exact case/arm/metric selection preserves simultaneous same-protocol arms, including three or more variants, rather than choosing a protocol's first row. The A1–A3 fixes remain covered.

This short smoke workload and its figures are diagnostic only, with no performance, superiority, noninferiority or paper-result inference. The analyzer's 18 synthetic tests passed before this read-only evidence analysis. No simulations or new seeds were used.

Runtime: `/opt/homebrew/opt/python@3.14/bin/python3.14`, Python 3.14.8, NumPy 2.5.3, Matplotlib 3.11.2.

```sh
python3 tools/analyze_secon2027.py --plan results/secon2027/plans/p0-smoke-v3.json --out-dir results/secon2027/analysis/p0-smoke-v3-analysis-v3
```

`analysis.json` contains generated audit/output identities. This README and `supersession.json` were added afterward as interpretation/provenance notes and are not part of its generated file-hash inventory.
