# P0 smoke analysis validation only

This directory verifies the analysis CLI against all 21 completed runs of the frozen `p0-smoke-v3` plan. The input is a short correctness/integration smoke workload. Its generated statistics and figures are diagnostic artifacts and must not support performance, superiority, noninferiority, or paper-result claims.

The input audit completed with 21/21 planned runs and no missing or failed attempts. Analysis read the immutable evidence and did not run simulations.

Invocation:

```sh
python3 tools/analyze_secon2027.py --plan results/secon2027/plans/p0-smoke-v3.json --out-dir results/secon2027/analysis/p0-smoke-v3
```

Executed runtime: `/opt/homebrew/opt/python@3.14/bin/python3.14`, Python 3.14.8, NumPy 2.5.3, Matplotlib 3.11.2. The independent synthetic analyzer test suite passed 11/11 immediately before this invocation. The complete machine-readable audit, source hashes, output hashes, and limitations are in `analysis.json`. This README is an interpretation label added after CLI completion and is not included in that generated file-hash inventory.
