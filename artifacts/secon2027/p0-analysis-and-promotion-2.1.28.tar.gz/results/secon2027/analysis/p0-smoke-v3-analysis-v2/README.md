# P0 smoke analysis validation only — corrected v2

This is the current diagnostic analysis of all 21 completed runs in frozen `p0-smoke-v3`. It supersedes `../p0-smoke-v3/analysis.json`, whose initial R/F choice counts and RREP receiver-role labels were incorrect. The earlier analysis and all raw evidence remain unchanged. `supersession.json` records both report/source identities and the correction reasons.

The corrected analyzer recognizes exported `R_INITIAL`/`F_INITIAL` values, classifies RREP next hops from forward path indexing, and admits only comparisons with verified resolved single-component parameter differences to the clean ablation panel. Broader fault-window active/enqueued populations are separate from initial carried-path fault exposure; zero carried-path exposure remains explicit.

This short smoke workload verifies correctness and integration. Its statistics and figures are diagnostic only and must not support performance, superiority, noninferiority, or paper-result claims. Core timely PDR, physical airtime and started-request metrics are unchanged across all 21 runs.

The independent synthetic analyzer suite passed 15/15 before this invocation. Runtime: `/opt/homebrew/opt/python@3.14/bin/python3.14`, Python 3.14.8, NumPy 2.5.3, Matplotlib 3.11.2. No simulations were run.

```sh
python3 tools/analyze_secon2027.py --plan results/secon2027/plans/p0-smoke-v3.json --out-dir results/secon2027/analysis/p0-smoke-v3-analysis-v2
```

Machine-generated results and hashes are in `analysis.json`. This README and `supersession.json` are interpretation/supersession records added after CLI completion and are not included in its generated file-hash inventory.
