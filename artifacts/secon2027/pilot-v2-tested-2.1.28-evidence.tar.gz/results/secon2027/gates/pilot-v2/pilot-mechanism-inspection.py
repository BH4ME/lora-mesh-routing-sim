#!/usr/bin/env python3
"""Read immutable completed pilot evidence; never run a simulation."""
from collections import Counter, defaultdict, deque
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parent / "repo"


def lines(path):
    with path.open() as stream:
        for line in stream:
            if line.strip():
                yield json.loads(line)


def edge(a, b):
    return tuple(sorted((a, b)))


def intended(tx):
    path, index = tx["path"], tx["path_index"]
    if tx["packet_kind"] in {"DATA", "RREP"} and 0 <= index < len(path) - 1:
        return path[index + 1]
    if tx["packet_kind"] == "ACK" and 0 <= index < len(path):
        return path[index]
    return None


def q(values, quantile):
    if not values:
        return None
    values = sorted(values)
    pos = quantile * (len(values) - 1)
    lo, hi = math.floor(pos), math.ceil(pos)
    return values[lo] + (values[hi] - values[lo]) * (pos - lo)


def shortest(env, source, destination, time):
    removed = {edge(*e) for fault in env.get("faults", [])
               if fault["start_s"] <= time < fault["end_s"] and fault["attenuation_db"] >= 60
               for e in fault["edges"]}
    graph = defaultdict(list)
    for a, b in env["neighbor_edges"]:
        if edge(a, b) not in removed:
            graph[a].append(b)
            graph[b].append(a)
    queue, seen = deque([(source, 0)]), {source}
    while queue:
        node, hops = queue.popleft()
        if node == destination:
            return hops
        for other in graph[node]:
            if other not in seen:
                seen.add(other)
                queue.append((other, hops + 1))
    return None


def inspect(spec, attempt):
    completion = json.loads((attempt / "completion.json").read_text())
    identity = json.loads((attempt / "evidence.identities.json").read_text())[str(spec["seed"])]
    env = identity["common_environment"]
    faults = env.get("faults", [])
    flows = {f["flow_id"]: f for f in lines(attempt / "evidence.flows.jsonl")}
    txs = {t["tx_id"]: t for t in lines(attempt / "evidence.transmissions.jsonl")}
    actions = list(lines(attempt / "evidence.actions.jsonl"))
    requests = list(lines(attempt / "evidence.requests.jsonl"))
    acks = list(lines(attempt / "evidence.acks.jsonl"))
    with (attempt / "evidence.runs.csv").open() as stream:
        raw = next(csv.DictReader(stream))
    cutoff = float(raw["drain_until_s"])
    assert all(t["start"] <= cutoff and t["end"] >= t["start"] for t in txs.values())
    airtime = sum(t["end"] - t["start"] for t in txs.values())
    assert abs(airtime - float(raw["tx_ledger_airtime_s"])) < 1e-7
    assert len(txs) == int(raw["started_request_count"])
    by_flow, source_txs = defaultdict(list), []
    for tx in txs.values():
        by_flow[tx["flow_id"]].append(tx)
        if tx["sender"] == flows[tx["flow_id"]]["src"] and tx["packet_kind"] in {"DATA", "FLOOD", "FALLBACK"}:
            source_txs.append(tx)
    initial = {}
    for tx in sorted(source_txs, key=lambda t: (t["start"], t["tx_id"])):
        initial.setdefault(tx["flow_id"], tx)
    fault_active, fault_enqueued, initial_before, initial_exposed = set(), set(), set(), set()
    active_alt_hops = Counter()
    for fid, flow in flows.items():
        stop = min(cutoff, flow["deadline_at"], flow["accepted_ack_at"] if flow["accepted_ack_at"] is not None else math.inf)
        first = initial.get(fid)
        for fault in faults:
            start, end = fault["start_s"], fault["end_s"]
            if start <= flow["enqueued_at"] < end:
                fault_enqueued.add(fid)
            if max(start, flow["enqueued_at"]) < min(end, stop):
                fault_active.add(fid)
                hops = shortest(env, flow["src"], flow["dst"], max(start, flow["enqueued_at"]))
                active_alt_hops[str(hops)] += 1
                if first and first["start"] < start:
                    initial_before.add(fid)
            if first and first["packet_kind"] == "DATA" and start <= first["start"] < end:
                path_edges = {edge(a, b) for a, b in zip(first["path"], first["path"][1:])}
                if path_edges & {edge(*e) for e in fault["edges"]}:
                    initial_exposed.add(fid)
    fault_txs, fault_data_flows, fault_before_flows = {}, set(), set()
    frame_overlap_only = []
    for tx in txs.values():
        receiver = intended(tx)
        if receiver is None:
            continue
        for fault in faults:
            if edge(tx["sender"], receiver) not in {edge(*e) for e in fault["edges"]}:
                continue
            if fault["start_s"] <= tx["start"] < fault["end_s"]:
                record = {k: tx[k] for k in ("tx_id", "flow_id", "packet_kind", "sender", "start", "end", "repair_index", "path", "path_index")}
                record["intended_receiver"] = receiver
                record["initial_source_tx_at"] = initial.get(tx["flow_id"], {}).get("start")
                record["initial_source_before_fault"] = record["initial_source_tx_at"] is not None and record["initial_source_tx_at"] < fault["start_s"]
                fault_txs[tx["tx_id"]] = record
                if tx["packet_kind"] == "DATA":
                    fault_data_flows.add(tx["flow_id"])
                    if record["initial_source_before_fault"]:
                        fault_before_flows.add(tx["flow_id"])
            elif max(tx["start"], fault["start_s"]) < min(tx["end"], fault["end_s"]):
                frame_overlap_only.append(tx["tx_id"])
    neighbors = {edge(*e) for e in env["neighbor_edges"]}
    all_rx, intended_rx, neighbor_rx, fault_rx = Counter(), Counter(), Counter(), Counter()
    intended_by_kind = defaultdict(Counter)
    for rx in lines(attempt / "evidence.rx_attempts.jsonl"):
        tx = txs[rx["tx_id"]]
        if rx["receiver"] == tx["sender"]:
            continue
        all_rx[rx["reason"]] += 1
        if edge(tx["sender"], rx["receiver"]) in neighbors:
            neighbor_rx[rx["reason"]] += 1
        if rx["receiver"] == intended(tx):
            intended_rx[rx["reason"]] += 1
            intended_by_kind[tx["packet_kind"]][rx["reason"]] += 1
            if tx["tx_id"] in fault_txs:
                fault_rx[rx["reason"]] += 1
                fault_txs[tx["tx_id"]]["rx_reason"] = rx["reason"]
                fault_txs[tx["tx_id"]]["rx_decoded"] = rx["decoded"]
    protocol = spec["arm"]["protocol"]
    is_cpr = protocol.startswith("meshecho-cpr")
    pre_fault_cache_evidence = []
    if is_cpr:
        parameters = identity.get("protocol_parameters_by_arm", {}).get(protocol, {})
        for fault in faults:
            start = fault["start_s"]
            for src, dst in sorted({(f["src"], f["dst"]) for f in flows.values()}):
                relevant = [a for a in actions if a.get("src") == src and a.get("dst") == dst and a["time"] < start]
                confirmed = [a for a in relevant if a["event"] == "ack-accept"
                             and a.get("cache_update") in {"refreshed-same-path", "installed-matching-epoch"}]
                latest = max(confirmed, key=lambda a:(a["time"],a["action_ordinal"])) if confirmed else None
                invalidations = [a for a in relevant if latest and (a["time"],a["action_ordinal"]) > (latest["time"],latest["action_ordinal"])
                                 and a["event"] == "timeout" and a.get("cache_timeout_effect") in {"evicted","quarantined"}]
                last_invalidation = max(invalidations,key=lambda a:(a["time"],a["action_ordinal"])) if invalidations else None
                path = latest["path"] if latest else []
                expires = latest["time"] + parameters["route_ttl_s"] if latest else None
                pre_fault_cache_evidence.append({"src":src,"dst":dst,"fault_start_s":start,
                    "last_logged_cache_confirmation_at":latest["time"] if latest else None,
                    "last_confirmed_path":path,"inferred_expires_at":expires,
                    "last_later_timeout_effect":last_invalidation["cache_timeout_effect"] if last_invalidation else None,
                    "ready_from_logged_confirmation_and_timeout_events":bool(latest and expires > start and not last_invalidation),
                    "last_confirmed_path_intersects_fault":bool({edge(a,b) for a,b in zip(path,path[1:])} & {edge(*e) for e in fault["edges"]})})
    repeats = [t for t in source_txs if is_cpr and t["packet_kind"] == "DATA" and t["repair_index"] == 1]
    recoveries = [t for t in source_txs if is_cpr and t["packet_kind"] == "FLOOD" and t["repair_index"] == 2]
    timely_acks = [f["accepted_ack_at"] - f["enqueued_at"] for f in flows.values() if f["ack_by_deadline"]]
    timely_deliveries = [f["first_delivery_at"] - f["enqueued_at"] for f in flows.values() if f["delivery_by_deadline"]]
    cost = Counter()
    for tx in txs.values():
        kind = tx["packet_kind"]
        stage = "discovery" if kind in {"RREQ", "RREP"} else {None:"initial",1:"repeat",2:"recovery"}.get(tx["repair_index"],"other") if is_cpr else "fallback" if kind == "FALLBACK" else "initial"
        cost[f"{kind}/{stage}"] += tx["end"] - tx["start"]
    assert abs(sum(cost.values()) - airtime) < 1e-7
    event_counts = Counter(a["event"] for a in actions)
    event_action_reason_counts = Counter((str(a.get("event")), str(a.get("action")), str(a.get("reason"))) for a in actions)
    flow_action_reason_counts = Counter((str(f.get("initial_action")), str(f.get("decision_reason"))) for f in flows.values())
    capacity = [a for a in actions if a["event"] == "state-eviction" and a.get("reason") == "capacity"]
    waits = [r["queue_wait_s"] for r in requests if r.get("queue_wait_s") is not None]
    accepted = [a for a in acks if a["accepted"]]
    return {"run_key":spec["run_key"],"case_id":spec["case_id"],"scenario":spec["case"]["scenario"],
            "configuration":spec["case"]["configuration"],"arm_id":spec["arm_id"],"protocol":protocol,"seed":spec["seed"],
            "wall_seconds":completion["wall_seconds"],"peak_rss_native":completion["audit"]["peak_rss_native"],
            "peak_rss_unit":completion["audit"]["peak_rss_unit"],
            "attempt_bytes":sum(p.stat().st_size for p in attempt.iterdir() if p.is_file()),
            "event_jsonl_bytes":sum(p.stat().st_size for p in attempt.glob('evidence.*.jsonl')),
            "flow_count":len(flows),"timely_ack_count":len(timely_acks),"timely_delivery_count":len(timely_deliveries),
            "ack_pdr":len(timely_acks)/len(flows),"delivery_pdr":len(timely_deliveries)/len(flows),
            "airtime_s":airtime,"physical_tx_count":len(txs),"airtime_per_delivery_s":airtime/len(timely_deliveries) if timely_deliveries else None,
            "ack_latency_p50_s":q(timely_acks,.5),"ack_latency_p95_s":q(timely_acks,.95),
            "delivery_latency_p50_s":q(timely_deliveries,.5),"delivery_latency_p95_s":q(timely_deliveries,.95),
            "initial_actions":dict(Counter(str(f.get("initial_action")) for f in flows.values())),
            "flow_action_reason_counts":[{"action":a,"reason":r,"count":n} for (a,r),n in sorted(flow_action_reason_counts.items())],
            "event_action_reason_counts":[{"event":e,"action":a,"reason":r,"count":n} for (e,a,r),n in sorted(event_action_reason_counts.items())],
            "accepted_ack_hops":dict(Counter(str(len(a["reverse_path"])-1) for a in accepted)),
            "source_repeats":len(repeats),"source_recoveries":len(recoveries),
            "repeat_flow_ids":[t["flow_id"] for t in repeats],"recovery_flow_ids":[t["flow_id"] for t in recoveries],
            "recovery_after_destination_delivery":sum(flows[t["flow_id"]]["first_delivery_at"] is not None and flows[t["flow_id"]]["first_delivery_at"] < t["start"] for t in recoveries),
            "accepted_ack_stage":dict(Counter(str(a["repair_index"]) for a in accepted)),
            "event_counts":dict(event_counts),"capacity_evictions":len(capacity),
            "capacity_evictions_by_node":dict(Counter(str(a.get("node")) for a in capacity)),"ledger_peak_occupancy":None,
            "capacity_pending_canceled":sum(bool(a.get("pending_canceled")) for a in capacity),
            "cancel_checks":event_counts["cpr-cancel-check"],"cancel_successes":event_counts["cpr-cancel"],
            "request_status":dict(Counter(r["status"] for r in requests)),
            "request_no_start_reason":dict(Counter(str(r.get("no_start_reason")) for r in requests if r["status"] != "started")),
            "queue_wait_mean_s":statistics.fmean(waits) if waits else None,"queue_wait_p95_s":q(waits,.95),
            "all_listener_rx":dict(all_rx),"neighbor_listener_rx":dict(neighbor_rx),"intended_rx":dict(intended_rx),
            "intended_rx_by_kind":dict(intended_by_kind),"fault_intended_rx":dict(fault_rx),
            "fault_enqueued_flows":len(fault_enqueued),"fault_active_flows":len(fault_active),
            "fault_active_initial_before_flows":len(initial_before),"fault_initial_carried_path_exposed_flows":len(initial_exposed),
            "fault_physical_intended_tx":len(fault_txs),"fault_physical_data_flows":len(fault_data_flows),
            "fault_physical_data_flows_initial_before":len(fault_before_flows),"fault_edge_tx_details":list(fault_txs.values()),
            "fault_frame_overlap_but_start_outside_tx_ids":frame_overlap_only,"fault_active_structural_hops":dict(active_alt_hops),
            "pre_fault_cache_evidence":pre_fault_cache_evidence,
            "cost_partition_airtime_s":dict(cost),"effective_parameters":identity.get("protocol_parameters_by_arm",{})}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True, help="exclusive new JSON output")
    args = parser.parse_args()
    plan_path = (args.plan if args.plan.is_absolute() else ROOT / args.plan).resolve()
    output_path = args.out.resolve()
    if output_path.exists():
        raise FileExistsError(output_path)
    plan = json.loads(plan_path.read_text())
    assert len(plan["runs"]) == 72
    attempts = []
    for spec in plan["runs"]:
        root = ROOT / "results/secon2027/runs" / spec["run_key"]
        complete = list(root.glob("attempt-*/completion.json"))
        if len(complete) != 1:
            raise SystemExit(f"Full coverage not yet established for {spec['run_key']}: {len(complete)} completed attempts")
        attempts.append((spec, complete[0].parent))
    # Full frozen-plan audit is allowed only after the simple completeness gate.
    sys.path.insert(0,str(ROOT))
    from tools.secon2027_experiment import audit_plan
    audit = audit_plan(plan_path,ROOT)
    assert audit["status"] == "complete" and len(audit["completed"]) == 72
    rows = [inspect(spec, attempt) for spec,attempt in attempts]
    result = {"schema":"pilot-mechanism-inspection-v1","scope":"development-only-no-confirmatory-inference",
              "plan_sha256":plan["plan_sha256"],"source_snapshot":plan["source_snapshot"],
              "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"audit":audit,"runs":rows}
    with output_path.open("x") as stream:
        json.dump(result,stream,indent=2,sort_keys=True,allow_nan=False)
        stream.write("\n")
    print(json.dumps({"completed_runs":len(rows),"output":str(output_path)}))


if __name__ == "__main__":
    main()
