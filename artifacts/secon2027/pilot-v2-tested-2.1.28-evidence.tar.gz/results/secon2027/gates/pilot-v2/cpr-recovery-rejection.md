# CPR stale-route recovery rejection repair

Date: 2026-11-04. Production change: import `CprDecision` from
`meshecho_cpr` in `lora_mesh_sim.py`. No controller policy, timer, parameter,
source budget or acceptance criterion was changed.

## Failure evidence and root cause

Pilot-v1 run
`79351a989e26b20a449f1d5522fa2303ad7b9ad2a181ecd5c58bc7c54a1a6577`,
`attempt-001/stderr.log`, records a `NameError` in `_cpr_start_recovery`
while building the `stale-route-generation` rejection. That branch calls
`CprDecision`, which was defined in `meshecho_cpr.py` but absent from the
simulator's import list. The pure selector's ordinary returns did not need
this symbol in the simulator module, so valid-route happy paths did not
expose the error. Tests importing the class into their own module did not
make the name available to production code.

The original pilot evidence and its source snapshot were read only and
remain untouched. The deterministic regression below establishes a real
reachable trigger for the same branch; it does not reconstruct or claim
which route-invalidity subtype caused the unavailable partial pilot trace.

## Deterministic regression

`tests/test_meshecho_cpr_controller.py::test_cpr_recovery_rejects_route_quarantined_after_concurrent_repeat`
uses a two-node test fixture with legacy test seed 92000. It schedules real
application events and runs the unmodified controller/event loop. A warmup
DATA-FLOOD/ACK exchange learns the path. A fixture channel then drops the
payloads of two later flows; it does not patch the controller, its selector,
admission function or timers.

The second unconfirmed flow's deadline falls after the third flow's physical
repeat but before its recovery request. The timeout quarantines their shared
route. Recovery consequently enters the actual invalid-route rejection
branch through `Simulator.run -> begin_transmission -> on_tx_request`.

Before the import fix, the test failed with the same `NameError` at recovery
start 31.199496 s. After the one-line fix, it verifies that the recovery
request receives `DROP_DEADLINE_INFEASIBLE / stale-route-generation`, that
the third source emitted exactly initial DATA and one repeat with no recovery
FLOOD, and that all three scheduled flows remain recorded without inventing
an ACK.

## Recorded validation

- `cpr-recovery-rejection-red.log` / `.json`: targeted test, exit 1,
  **1 failed**; includes full traceback and pre-fix source SHA-256.
- `cpr-recovery-rejection-green.log` / `.json`: same targeted test, exit 0,
  **1 passed in 0.17 s**; post-fix source SHA-256 recorded.
- `cpr-drc-regression.log` / `.json`: CPR selector/controller/correctness and
  DRC selector/controller suites, exit 0, **79 passed in 0.12 s**.
- Targeted `git diff --check` passed.

All commands use `/usr/bin/python3 -m pytest`. This gate ran no research
cohort, changed no seed registry and resumed no failed pilot attempt. The
parent owns frozen-snapshot creation, complete replacement pilot planning,
broader frozen verification and publication/version mapping.
